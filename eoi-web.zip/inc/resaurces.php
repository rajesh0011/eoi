<section class="section resources">
    <div class="container">
        <div class="text-center">
            <h2 class="section-title"><span>Resources</span></h2>
        </div>
        <div class="row resaurces-bx">
           <div class="col-md-4">
                <div class="article-sidebar">
                    <div class="">
                        <h2 class="section-title">Articles</h2>
                    </div>
                    <div class="articles-list">
                        <div class="card">
                            <div class="card-body news-media-slider">
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>
                                <div>
                                  <div class="strip-text">
                                        <a href="#" target="_blank"><i class="bi bi-record-circle"></i>  Lorem Ipsum is simply dummy text of the printing and typesetting industry </a>
                                  </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
           </div>

           <div class="col-md-8">
                <div class="video-sidebar">
                    <div class="">
                        <h2 class="section-title">Videos</h2>
                    </div>
                    <div class="videos-box">
                        <ul>
                            <li>
                                <iframe src="https://www.youtube.com/embed/0vXKUDFhXiU?si=2c7NDNE0pae0U2XI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </li>
                            <li>
                                <iframe src="https://www.youtube.com/embed/0vXKUDFhXiU?si=2c7NDNE0pae0U2XI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </li>
                            <li>
                                <iframe src="https://www.youtube.com/embed/0vXKUDFhXiU?si=2c7NDNE0pae0U2XI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </li>
                            <li>
                                <iframe src="https://www.youtube.com/embed/0vXKUDFhXiU?si=2c7NDNE0pae0U2XI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </li>
                        </ul>
                    </div>
                </div>
           </div>

        </div>
    </div>
</section>